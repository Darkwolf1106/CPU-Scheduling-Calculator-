function toggleAlgorithm() {
  const selectedAlgorithm = document.getElementById("algorithmSelect").value;
  document.getElementById("roundRobinSection").style.display =
    selectedAlgorithm === "roundRobin" ? "block" : "none";
  document.getElementById("srtSection").style.display =
    selectedAlgorithm === "srt" ? "block" : "none";
  document.getElementById("nonPreemptivePrioritySection").style.display =
    selectedAlgorithm === "nonPreemptivePriority" ? "block" : "none";
    document.getElementById("PreemptivePrioritySection").style.display =
  selectedAlgorithm === "PreemptivePriority" ? "block" : "none";
}

function calculateRoundRobin() {
  const arrivalTimes = document.getElementById("rrArrivalTimes").value.split(" ").map(Number);
  const burstTimes = document.getElementById("rrBurstTimes").value.split(" ").map(Number);
  const timeQuantum = parseInt(document.getElementById("rrTimeQuantum").value);

  const n = arrivalTimes.length;
  const remainingTimes = [...burstTimes];
  const finishTimes = Array(n).fill(0);
  const turnaroundTimes = Array(n).fill(0);
  const waitingTimes = Array(n).fill(0);

  let time = 0;
  let completed = 0;
  const ganttChart = [];
  const queue = [];
  const visited = Array(n).fill(false);

  while (completed < n) {
    for (let i = 0; i < n; i++) {
      if (arrivalTimes[i] <= time && !visited[i] && remainingTimes[i] > 0) {
        queue.push(i);
        visited[i] = true;
      }
    }

    if (queue.length === 0) {
      time++;
      continue;
    }

    const currentProcess = queue.shift();
    ganttChart.push({ process: String.fromCharCode(65 + currentProcess), time });

    if (remainingTimes[currentProcess] <= timeQuantum) {
      time += remainingTimes[currentProcess];
      remainingTimes[currentProcess] = 0;
      finishTimes[currentProcess] = time;
      turnaroundTimes[currentProcess] = finishTimes[currentProcess] - arrivalTimes[currentProcess];
      waitingTimes[currentProcess] = turnaroundTimes[currentProcess] - burstTimes[currentProcess];
      completed++;
    } else {
      time += timeQuantum;
      remainingTimes[currentProcess] -= timeQuantum;

      for (let i = 0; i < n; i++) {
        if (arrivalTimes[i] <= time && !visited[i] && remainingTimes[i] > 0) {
          queue.push(i);
          visited[i] = true;
        }
      }
      queue.push(currentProcess);
    }
  }

  const avgTurnaroundTime = (turnaroundTimes.reduce((sum, val) => sum + val, 0) / n).toFixed(2);
  const avgWaitingTime = (waitingTimes.reduce((sum, val) => sum + val, 0) / n).toFixed(2);

  const tableBody = document.querySelector("#rrOutputTable tbody");
  tableBody.innerHTML = "";
  arrivalTimes.forEach((at, i) => {
    tableBody.innerHTML += `
      <tr>
        <td>${String.fromCharCode(65 + i)}</td>
        <td>${at}</td>
        <td>${burstTimes[i]}</td>
        <td>${finishTimes[i]}</td>
        <td>${turnaroundTimes[i]}</td>
        <td>${waitingTimes[i]}</td>
      </tr>`;
  });

  const ganttChartHtml = ganttChart
    .map((entry) => `<div class="gantt-box"><span>${entry.process}</span></div>`)
    .join("");
  const timeMarkersHtml = ganttChart
    .map((entry) => `<span class="time-marker">${entry.time}</span>`)
    .join("") + `<span class="time-marker">${time}</span>`;

  document.getElementById("rrGanttChart").innerHTML = `
    <h3>Average Waiting Time: ${avgWaitingTime}</h3>
    <h3>Average Turnaround Time: ${avgTurnaroundTime}</h3>
    <h3>GANTT CHART:</h3>
    <div class="gantt-container">
      <div class="time-row">${timeMarkersHtml}</div>
      <div class="gantt-row">${ganttChartHtml}</div>
    </div>`;
}

function calculateSRT() {
  const arrivalTimes = document.getElementById("srtArrivalTimes").value.split(" ").map(Number);
  const burstTimes = document.getElementById("srtBurstTimes").value.split(" ").map(Number);

  const n = arrivalTimes.length;
  const remainingTimes = [...burstTimes];
  const finishTimes = Array(n).fill(0);
  const turnaroundTimes = Array(n).fill(0);
  const waitingTimes = Array(n).fill(0);
  const ganttChart = [];

  let time = 0;
  let completed = 0;

  while (completed < n) {
    let currentProcess = -1;
    let minRemainingTime = Infinity;

    for (let i = 0; i < n; i++) {
      if (arrivalTimes[i] <= time && remainingTimes[i] > 0 && remainingTimes[i] < minRemainingTime) {
        minRemainingTime = remainingTimes[i];
        currentProcess = i;
      }
    }

    if (currentProcess === -1) {
      time++;
      continue;
    }

    if (
      ganttChart.length === 0 ||
      ganttChart[ganttChart.length - 1].process !== String.fromCharCode(65 + currentProcess)
    ) {
      ganttChart.push({ process: String.fromCharCode(65 + currentProcess), start: time });
    }

    remainingTimes[currentProcess]--;
    time++;

    if (remainingTimes[currentProcess] === 0) {
      completed++;
      finishTimes[currentProcess] = time;
      turnaroundTimes[currentProcess] = finishTimes[currentProcess] - arrivalTimes[currentProcess];
      waitingTimes[currentProcess] = turnaroundTimes[currentProcess] - burstTimes[currentProcess];
    }
  }

  ganttChart.forEach((entry, index) => {
    entry.end = ganttChart[index + 1]?.start || time;
  });

  const avgTurnaroundTime = (turnaroundTimes.reduce((sum, val) => sum + val, 0) / n).toFixed(2);
  const avgWaitingTime = (waitingTimes.reduce((sum, val) => sum + val, 0) / n).toFixed(2);

  const tableBody = document.querySelector("#srtOutputTable tbody");
  tableBody.innerHTML = "";
  arrivalTimes.forEach((at, i) => {
    tableBody.innerHTML += `
      <tr>
        <td>${String.fromCharCode(65 + i)}</td>
        <td>${at}</td>
        <td>${burstTimes[i]}</td>
        <td>${finishTimes[i]}</td>
        <td>${turnaroundTimes[i]}</td>
        <td>${waitingTimes[i]}</td>
      </tr>`;
  });

  const ganttChartHtml = ganttChart
    .map((entry) => `<div class="gantt-box"><span>${entry.process}</span></div>`)
    .join("");
  const timeMarkersHtml = ganttChart
    .map((entry) => `<span class="time-marker">${entry.start}</span>`)
    .join("") + `<span class="time-marker">${time}</span>`;

  document.getElementById("srtGanttChart").innerHTML = `
    <h3>Average Waiting Time: ${avgWaitingTime}</h3>
    <h3>Average Turnaround Time: ${avgTurnaroundTime}</h3>
    <h3>GANTT CHART:</h3>
    <div class="gantt-container">
      <div class="time-row">${timeMarkersHtml}</div>
      <div class="gantt-row">${ganttChartHtml}</div>
    </div>`;
}

// Non-Preemptive Priority Scheduling Calculator
function calculatenonPreemptivePriority() {
  const arrivalTimes = document.getElementById("nonPreemptivePriorityarrivalTimes").value.split(" ").map(Number);
  const burstTimes = document.getElementById("nonPreemptivePriorityburstTimes").value.split(" ").map(Number);
  const priorities = document.getElementById("nonPreemptivePrioritypriorities").value.split(" ").map(Number);

  const n = arrivalTimes.length;
  const finishTimes = Array(n).fill(0);
  const turnaroundTimes = Array(n).fill(0);
  const waitingTimes = Array(n).fill(0);
  const ganttChart = [];

  let currentTime = 0;
  let completed = 0;
  const isCompleted = Array(n).fill(false);

  while (completed < n) {
    let currentProcess = -1;
    let minPriority = Infinity;

    for (let i = 0; i < n; i++) {
      if (
        arrivalTimes[i] <= currentTime &&
        !isCompleted[i] &&
        priorities[i] < minPriority
      ) {
        minPriority = priorities[i];
        currentProcess = i;
      }
    }

    if (currentProcess === -1) {
      currentTime++;
      continue;
    }

    // Record Gantt chart entry
    ganttChart.push({
      process: String.fromCharCode(65 + currentProcess),
      start: currentTime,
      end: currentTime + burstTimes[currentProcess]
    });

    // Update times for the current process
    currentTime += burstTimes[currentProcess];
    finishTimes[currentProcess] = currentTime;
    turnaroundTimes[currentProcess] = finishTimes[currentProcess] - arrivalTimes[currentProcess];
    waitingTimes[currentProcess] = turnaroundTimes[currentProcess] - burstTimes[currentProcess];
    isCompleted[currentProcess] = true;
    completed++;
  }

  const avgTurnaroundTime = (
    turnaroundTimes.reduce((sum, val) => sum + val, 0) / n
  ).toFixed(2);
  const avgWaitingTime = (
    waitingTimes.reduce((sum, val) => sum + val, 0) / n
  ).toFixed(2);

  const tableBody = document.querySelector("#nonPreemptivePriorityoutputTable tbody");
  tableBody.innerHTML = "";
  arrivalTimes.forEach((at, i) => {
    tableBody.innerHTML += `
      <tr>
        <td>${String.fromCharCode(65 + i)}</td>
        <td>${at}</td>
        <td>${burstTimes[i]}</td>
        <td>${priorities[i]}</td>
        <td>${finishTimes[i]}</td>
        <td>${turnaroundTimes[i]}</td>
        <td>${waitingTimes[i]}</td>
      </tr>`;
  });

  const ganttChartHtml = ganttChart.map(entry => `
    <div class="gantt-box">
      <span>${entry.process}</span>
    </div>
  `).join("");

  const timeMarkersHtml = ganttChart.map(entry => `
    <span class="time-marker">${entry.start}</span>
  `).join("") + `<span class="time-marker">${ganttChart[ganttChart.length - 1].end}</span>`;

  document.getElementById("nonPreemptivePriorityganttChart").innerHTML = `
    <h3>Average Waiting Time: ${avgWaitingTime}</h3>
    <h3>Average Turnaround Time: ${avgTurnaroundTime}</h3>
    <h3>GANTT CHART:</h3>
    <div class="gantt-container">
      <div class="time-row">${timeMarkersHtml}</div>
      <div class="gantt-row">${ganttChartHtml}</div>
    </div>`;
}


function calculatePreemptivePriority() {
  const arrivalTimes = document.getElementById("PreemptivePriorityarrivalTimes").value.split(" ").map(Number);
  const burstTimes = document.getElementById("PreemptivePriorityburstTimes").value.split(" ").map(Number);
  const priorities = document.getElementById("PreemptivePrioritypriorities").value.split(" ").map(Number);

  const n = arrivalTimes.length;
  const remainingTimes = [...burstTimes];
  const finishTimes = Array(n).fill(0);
  const turnaroundTimes = Array(n).fill(0);
  const waitingTimes = Array(n).fill(0);
  const ganttChart = [];

  let time = 0;
  let completed = 0;

  while (completed < n) {
    let currentProcess = -1;
    let minPriority = Infinity;

    for (let i = 0; i < n; i++) {
      if (
        arrivalTimes[i] <= time &&
        remainingTimes[i] > 0 &&
        priorities[i] < minPriority
      ) {
        minPriority = priorities[i];
        currentProcess = i;
      }
    }

    if (currentProcess === -1) {
      time++;
      continue;
    }

    // Add to Gantt chart if different from last entry or chart is empty
    if (
      ganttChart.length === 0 ||
      ganttChart[ganttChart.length - 1].process !== String.fromCharCode(65 + currentProcess)
    ) {
      ganttChart.push({
        process: String.fromCharCode(65 + currentProcess),
        start: time,
      });
    }

    remainingTimes[currentProcess]--;
    time++;

    if (remainingTimes[currentProcess] === 0) {
      completed++;
      finishTimes[currentProcess] = time;
      turnaroundTimes[currentProcess] = finishTimes[currentProcess] - arrivalTimes[currentProcess];
      waitingTimes[currentProcess] = turnaroundTimes[currentProcess] - burstTimes[currentProcess];
    }
  }

  // Finalize the Gantt chart end times
  ganttChart.forEach((entry, index) => {
    if (index < ganttChart.length - 1) {
      entry.end = ganttChart[index + 1].start;
    } else {
      entry.end = time;
    }
  });

  const avgTurnaroundTime = (
    turnaroundTimes.reduce((sum, val) => sum + val, 0) / n
  ).toFixed(2);
  const avgWaitingTime = (
    waitingTimes.reduce((sum, val) => sum + val, 0) / n
  ).toFixed(2);

  const tableBody = document.querySelector("#PreemptivePriorityoutputTable tbody");
  tableBody.innerHTML = "";
  arrivalTimes.forEach((at, i) => {
    tableBody.innerHTML += `
      <tr>
        <td>${String.fromCharCode(65 + i)}</td>
        <td>${at}</td>
        <td>${burstTimes[i]}</td>
        <td>${priorities[i]}</td>
        <td>${finishTimes[i]}</td>
        <td>${turnaroundTimes[i]}</td>
        <td>${waitingTimes[i]}</td>
      </tr>`;
  });

  const ganttChartHtml = ganttChart.map(entry => `
    <div class="gantt-box">
      <span>${entry.process}</span>
    </div>
  `).join("");
  
  // Generate time markers to be placed between process boxes
  const timeMarkersHtml = ganttChart.map((entry, index) => {
    const nextTime = ganttChart[index + 1]?.start || entry.end;
    return `
      <span class="time-marker">${entry.start}</span>`;
  }).join("") + `<span class="time-marker">${time}</span>`;
  
  document.getElementById("PreemptivePriorityganttChart").innerHTML = `
    <h3>Average Waiting Time: ${avgWaitingTime}</h3>
    <h3>Average Turnaround Time: ${avgTurnaroundTime}</h3>
    <h3>GANTT CHART:</h3>
    <div class="gantt-container">
      <div class="time-row">${timeMarkersHtml}</div>
      <div class="gantt-row">${ganttChartHtml}</div>
    </div>`;
}